package com.example.mailservice.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "mail_config")
public class MailConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String host;
    private int port;
    private String username;
    private String password;
    private String protocol;
    private boolean auth;
    private boolean starttls;
    private boolean active;

    public Long getId() { return id; }
    public String getHost() { return host; }
    public int getPort() { return port; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getProtocol() { return protocol; }
    public boolean isAuth() { return auth; }
    public boolean isStarttls() { return starttls; }
    public boolean isActive() { return active; }

    public void setId(Long id) { this.id = id; }
    public void setHost(String host) { this.host = host; }
    public void setPort(int port) { this.port = port; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setProtocol(String protocol) { this.protocol = protocol; }
    public void setAuth(boolean auth) { this.auth = auth; }
    public void setStarttls(boolean starttls) { this.starttls = starttls; }
    public void setActive(boolean active) { this.active = active; }
}
