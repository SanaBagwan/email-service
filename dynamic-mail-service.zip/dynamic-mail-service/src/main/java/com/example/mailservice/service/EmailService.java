package com.example.mailservice.service;

import com.example.mailservice.dto.EmailRequest;
import com.example.mailservice.entity.MailConfig;
import com.example.mailservice.repository.MailConfigRepository;
import com.example.mailservice.util.DynamicMailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final MailConfigRepository repository;
    private final DynamicMailSender mailSenderBuilder;

    public EmailService(MailConfigRepository repository,
                        DynamicMailSender mailSenderBuilder) {
        this.repository = repository;
        this.mailSenderBuilder = mailSenderBuilder;
    }

    public void sendEmail(EmailRequest request) {

        MailConfig config = repository.findByActiveTrue()
                .orElseThrow(() -> new RuntimeException("Mail configuration not found"));

        JavaMailSender mailSender = mailSenderBuilder.createSender(config);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(request.getToMail());
        message.setSubject(request.getSubject());
        message.setText(request.getBody());
        message.setFrom(config.getUsername());

        mailSender.send(message);
    }
}
