package com.example.mailservice.controller;

import com.example.mailservice.dto.ApiResponse;
import com.example.mailservice.dto.EmailRequest;
import com.example.mailservice.service.EmailService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class NotificationController {

    private final EmailService mailService;

    public NotificationController(EmailService mailService) {
        this.mailService = mailService;
    }

    @PostMapping("/sendNotification")
    public ResponseEntity<ApiResponse> sendNotification(
            @Valid @RequestBody EmailRequest request
    ) {
        try {
            mailService.sendEmail(request);

            return ResponseEntity.ok(
                    new ApiResponse(
                            "SUCCESS",
                            "Email sent successfully",
                            null
                    )
            );
        } catch (Exception e) {
            e.printStackTrace();

            return ResponseEntity.internalServerError().body(
                    new ApiResponse(
                            "FAILED",
                            null,
                            "Unable to send email"
                    )
            );
        }
    }
}
