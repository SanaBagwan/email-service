package com.example.mailservice.dto;

public class ApiResponse {

    private String status;
    private String message;
    private String error;

    public ApiResponse(String status, String message, String error) {
        this.status = status;
        this.message = message;
        this.error = error;
    }

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public String getError() { return error; }
}
