package com.example.mailservice.repository;

import com.example.mailservice.entity.MailConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MailConfigRepository extends JpaRepository<MailConfig, Long> {

    Optional<MailConfig> findByActiveTrue();
}
