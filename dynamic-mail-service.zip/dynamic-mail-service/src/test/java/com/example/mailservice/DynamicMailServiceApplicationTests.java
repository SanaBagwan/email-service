package com.example.mailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicMailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
